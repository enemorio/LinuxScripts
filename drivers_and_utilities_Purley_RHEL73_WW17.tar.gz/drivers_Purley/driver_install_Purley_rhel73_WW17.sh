#!/bin/bash

# Previous to driver install
before_driver_intstall() {
mkdir -p /root/Desktop/driver_install_logs
echo "
Drivers before install:
" >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
i40e" > ~/Desktop/driver_install_logs/installed_drivers.log
modinfo i40e | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
igb" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo igb | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
ixgbe" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo ixgbe | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
mpt3sas" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo mpt3sas | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
megaraid_sas" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo megaraid_sas | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
megasr (ESRT2)" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo megasr | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log 2>&1
echo "

"
}

# BKC like RPM package installation
BKC_like() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing rpm packages to enable a BKC-like install

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
if [ -d /opt/BKCpkg ]; then
	echo "BKC Folder exists, installing missing RPM packages..."
	sleep 3
else 
	cp -rv /run/media/root/OS/BKCpkg /opt
fi

if [ -e "/run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso" ]; then
	mkdir -p /run/media/root/DVD
	mount -o loop /run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso /run/media/root/DVD
	cd /run/media/root/DVD/
	cp -f media.repo /etc/yum.repos.d/rhel73dvd.repo
	cd /etc/yum.repos.d/
	echo "baseurl=file:/run/media/root/DVD/" >> rhel73dvd.repo
	mkdir -p /root/Desktop/driver_install_logs
	yum install -y --skip-broken chrony kexec-tools zlib-devel openssl-devel boost-devel libvirt-devel libgudev1-devel ncurses-devel xterm telnet numactl-libs numactl-devel-*.i686 numactl-devel *.x86_64 OpenIPMI-*.x86_64 ncurses-devel-*.x86_64 expect-*.x86_64 dos2unix systemd-devel*.x86_64 boost-*.x86_64 glibc.i686 nmap xorg-x11-apps postgresql-libs perl-ExtUtils-Embed perl-XML-Twig perl-core libibmad libibumad libibumad-devel libibcm qperf perftest rdma infinipath-psm expat elfutils-libelf-devel atlas tcl expect tcsh sysfsutils pciutils bc graphviz libtool-ltdl-devel phonon net-snmp 2>&1 | tee /root/Desktop/driver_install_logs/BKC_like_rpm_install.log
	umount /run/media/root/DVD
fi
}

# Intel Lewisburg LAN (integrated motherboard) driver
install_i40e_LEK_722() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel Lewisburg LAN (integrated motherboard) driver (i40e LEK)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_LEK_X722/
tar -xf intel-lan_linux_v*.tar.gz
cd /opt/BKCpkg/driver/Intel_LEK_X722/linux/PRO40GB/
tar -xf i40e-*.tar.gz
cd i40e-*/src/
make install 2>&1 | tee /root/Desktop/driver_install_logs/i40e_LEK.log
}

# Intel NIC (PCI card LAN) 40GB driver
install_i40e_X550_T2() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel NIC (PCI card LAN) 40GB driver (i40e X550)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/
tar -xf intel-lan_linux_v*.tar.gz
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PRO40GB/
tar -xf i40e-*.tar.gz
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PRO40GB/i40e-*/src/
make install 2>&1 | tee /root/Desktop/driver_install_logs/i40e_X550.log
}

# Intel NIC (PCI card LAN) 1000GB driver
install_igb_X550_T2() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel NIC (PCI card LAN) 1000GB driver (igb X550)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PRO1000/
tar -xvf igb-*.tar.gz
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PRO1000/igb-*/src/
make install 2>&1 | tee /root/Desktop/driver_install_logs/igb_X550.log
}

# Intel NIC (PCI card LAN) XGB driver
install_ixgbe_X550_T2() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel NIC (PCI card LAN) XGB driver (ixgbe X550)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PROXGB/
tar -xf ixgbe-*.tar.gz
cd /opt/BKCpkg/driver/Intel_X550-T2/IntelEthernetConvergedNetworkAdapterX550-T2/linux/PROXGB/ixgbe-*/src/
make install 2>&1 | tee /root/Desktop/driver_install_logs/ixgbe_X550.log
}

# ESRT2 driver install using ahci (other options: ahci/isci/ahci_g)
install_ESRT2() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing LSI's ESRT2 driver using $1 (megasr)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_ESRT2/Linux_SWR_drv_*/
tar -xf megasr-drvr-bin.tgz
chmod +x /opt/BKCpkg/driver/Intel_ESRT2/Linux_SWR_drv_*/megasr-raid*/RHEL_7.3_RPM/install_rpm.sh
cd /opt/BKCpkg/driver/Intel_ESRT2/Linux_SWR_drv_*/megasr-raid5/RHEL_7.3_RPM/
rpm -vih *.rpm
/opt/BKCpkg/driver/Intel_ESRT2/Linux_SWR_drv_*/megasr-raid*/RHEL_7.3_RPM/./install_rpm.sh $1 2>&1 | tee /root/Desktop/driver_install_logs/ESRT2.log
}

# Intel mpt3sas RAID driver
install_mpt3sas_RAID() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel mpt3sas RAID driver (mpt3sas)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_RAID_IT_IR/MPT3SAS_ITIR_*/mpt3sas_*_rel/
tar -xf mpt3sas-release.tar.gz
cd /opt/BKCpkg/driver/Intel_RAID_IT_IR/MPT3SAS_ITIR_*/mpt3sas_*_rel/rhel7/rpms-*/
yum install * -y 2>&1 | tee /root/Desktop/driver_install_logs/mpt3sas.log
}

# Intel MegaRAID driver
install_megaRAID() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel MegaRAID driver (megaRAID)

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
mkdir -p /root/Desktop/driver_install_logs
cd /opt/BKCpkg/driver/Intel_RAID_MR_IMR/MR_Linux_drv_*/
tar -xf megaraid_sas_components.tgz
cd /opt/BKCpkg/driver/Intel_RAID_MR_IMR/MR_Linux_drv_*/rhel7_oel7_centos7/rpms-*/
yum install kmod-megaraid_sas-*_el7.3-1.x86_64.rpm -y 2>&1 | tee /root/Desktop/driver_install_logs/megaRAID.log
}

# Intel OPA Basic driver
install_OPA_Basic() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel OPA Basic driver

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
"
if [ -e "/run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso" ]; then
	mkdir -p /run/media/root/DVD
	mount -o loop /run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso /run/media/root/DVD
	cd /run/media/root/DVD/
	cp -f media.repo /etc/yum.repos.d/rhel73dvd.repo
	cd /etc/yum.repos.d/
	echo "baseurl=file:/run/media/root/DVD/" >> rhel73dvd.repo
	#cd /run/media/root/DVD/Packages
	mkdir -p /root/Desktop/driver_install_logs
	yum install -y libibmad libibumad libibumad-devel libibverbs librdmacm libibcm libpfm ibacm qperf perftest rdma infinipath-psm libhfi1 expat elfutils-libelf-devel libstdc++-devel gcc-gfortran atlas tcl expect tcsh sysfsutils pciutils bc opensm opensm-libs opensm-libs rpm-build redhat-rpm-config kernel-devel papi libibverbs-devel libibumad-devel librdmacm-devel  openssl-devel libuuid-devel expat-devel valgrind
	umount /run/media/root/DVD
fi


cd /opt/BKCpkg/driver/Intel_Omni-Path/
tar -xf IntelOPA-Basic.*.tgz
cd /opt/BKCpkg/driver/Intel_Omni-Path/IntelOPA-Basic.*/
./INSTALL -a 2>&1 | tee /root/Desktop/driver_install_logs/OPA_Basic.log
}

# After driver install
after_driver_intstall() {
echo "
After driver install:
" >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
i40e" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo i40e | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
igb" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo igb | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
ixgbe" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo ixgbe | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
mpt3sas" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo mpt3sas | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
megaraid_sas" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo megaraid_sas | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
echo "
megasr (ESRT2)" >> ~/Desktop/driver_install_logs/installed_drivers.log
modinfo megasr | grep -i version >> ~/Desktop/driver_install_logs/installed_drivers.log
cat ~/Desktop/driver_install_logs/installed_drivers.log
}

# Install QAT driver
install_QAT() {
echo "
 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

Installing Intel QAT driver

 :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

"
cd /opt/BKCpkg/driver/QAT/QAT*/
./installer.sh
}

create_cronjob() {
crontab -l > /etc/rc.d/cronjob
echo "@reboot service ipmi start" >> /etc/rc.d/cronjob
crontab -u root /etc/rc.d/cronjob
}

before_driver_intstall
#BKC_like
#install_i40e_LEK_722
install_i40e_X550_T2
install_igb_X550_T2
install_ixgbe_X550_T2
install_mpt3sas_RAID
install_megaRAID
install_OPA_Basic
install_ESRT2 ahci #megasr
#install_QAT
after_driver_intstall
create_cronjob
opaconfig

echo "
Driver installer finished. We created a log for you to review in /root/Desktop/installed_drivers.log

The system will now reboot. Please press enter or (Ctrl+c) to cancel reboot.
"
read
reboot
