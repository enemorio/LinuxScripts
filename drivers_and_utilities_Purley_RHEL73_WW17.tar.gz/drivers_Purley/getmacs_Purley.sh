#!/bin/bash
# This script was created on 021814 at 1328 on system EQXST31.
# Author Name: John Smith
# Script Name: getmacs.sh
#
#-------------- Script Purpose ---------------
#This script will read the network devices using lspci and report out the mac address on each port.
#
# ------------ Script Requirements ------------
# None
# ------------ Verified Operating Syatems ------------
# Red Hat 6.5
#
#
#
ifconfig|grep Ethernet > macs.txt
cat macs.txt


