#!/bin/bash
# log.sh - Log collection script
# Author: John Smith
scriptname=`echo log.sh`
#
# Version: 6.0
#
#-------------- Script Purpose ----------------
# The purpose of the script is to make system log collection easy and complete. It is
# always being updated and things are changing.
# This script collects system information which includes but is not limited to;
# OS message and MCE logs
# Optionally rotate the OS message log
# Ilvss results and package used
# BUS cycling logs
# Nearly all system information via Open Manage
# Drivers and their versions
# Storage related system information
# Network related system information
# All useful files from /etc including snmpd.conf
# All files from /boot/grub
# Dell DUP and update package logs
# Etc/modprobe.d is collected
# Information via racadm is also collected, including the SEL and LC logs
# System hardware information collected via 
# PCI-e adapter link states are also collected
# DMIdecode info
# Useful files from /proc
# All system network information
# Provides a list of all installed RPMs
# Captures dmesg output
# Captures the history file
# Collect ilvss logs, package used and reports errors to a separate error log. 
#
# ------------ Script Requirements ------------
# None to run but OM and racadm data collection will not happen if not installed.
#
#
# --------- Operating Systems Verified -------- 
# 
# SLES 11  x86_64 GM
# RHEL 5.9 x86_64
# RHEL 6.4 x86_64
# RHEL 6.5 x86_64 GA
# RHEL 7 RC		*Cannot be executed from a USB key due to execute permissions.
# RHEL 7.0 GA	*Cannot be executed from a USB key due to execute permissions.
#
#
# --------- Script Updates --------------------

#03/26/13 v1.0	For the script to get the Ilvss package that you used you will need to edit the line
# 				just below "#NOTE1" in the script.
#				*This note is no longer valid. The script now finds the newest package used and
#				copies it so no need for user input.
#03/28/13 v1.1	Cleaned up some verbiage and functionality around Open Manage.
#03/28/13 v1.2	The script now searches the message log for errors and puts the results in the same
# 				folder as the message log.
#04/02/13 v1.3	Added the option to clear the SEL after collection occurs.
#04/02/13 v1.4	Added the collection of the Life cycle Controller log.
#04/04/13 v1.5	Added a lot more data collection via Open Manage/omreport.
#04/18/13 v1.6	Added "lspci" standard output to lspci.txt.
#05/01/13 v1.7	Added a line that will display the PCI-e link capabilities and the current link state. 
#				It places "PCIelinks.txt" in the "/hardware" folder.
#05/22/13 v1.8	Added a better driver section that produces two text files. One contains all available
#				information for all drivers in the system(alldriverinfo.txt)and places it in the "/OS" folder. 
#				It also creates a condensed list of drivers and their versions(drivers.txt) in the "/OS" folder.
#06/04/13 v1.9	Removed the path to the module in the driver section output.
#06/17/13 v2.0	Removed "mail" & "crc" files from the collection process.
#07/29/13 v2.1	Remove the section that grep-ed the logs for errors into one file (got too big)!
#10/02/13 v2.2	Cleaning the procedures up and echoing less noise to the screen.
#				Also fixed a couple script errors...
#11/01/13 v2.3	Lots of updates;
#				Changed folder structure and placement of some files.
#11/12/13 v2.4	Changed the way I was resetting the message log (it was bad). I am now copying the log
#				and then clearing it with the "logrotate" command.
#11/22/13 v2.5	Added a prompt to rotate the OS logs after they were copied.
#				Added checks for certain logs before attempting to copy them.
#				Now copying all .conf files from /etc
#				Improved the PCI-e link section to align link capable with negotiated link for easy review.
#01/17/14 v2.6	Fixed the /etc/snmp/snmpd.conf file collection.
#				Added collection of the issue file.
#02/19/14 v2.7	Removed .bz2 files from the collection.
#				Moved the folder creation for CTC, OM, cycling and racadm.
#				Fixed the list of files included in the tarball. Previously was reporting all files
#				in the parent folder down instead of starting in the results folder.
#				Changed the y/n prompts to run without hitting Enter.
#02/20/14 v2.8	If the log runs without error, an error log with zero bytes was still left behind in the target
#				folder. This is fixed now so if the file exists then there were errors.
#02/21/14 v2.9	Added a function called "remove0bytefiles" which removes all zero byte files in all sub folders
#				prior to the creation of the tarball.
#				Previous .gz files were not being moved to ./oldtars - fixed
#				Zero byte function moved to just prior to creating the .gz file list thereby removing
#				zero byte files before the list is created.
#				This script is now verifying whether the "dsm_sa_datamgrd" service is running prior
#				to running the OM/Racadm section.
#02/26/14 v3.0	Did some formatting on the tarball file list that makes it easier to read.
#				Also cleaned up some messaging.
#				Alert! Major update of the script to organize the results more logically and results
#				are placed in more respective folders. Much easier to find the data this way.
#02/27/14 v3.1	Did more enhancements to the results organization and the script prints more information
#				about what its collecting while it runs. 		
#03/04/14 v3.0	Modified the Life cycle Controller human readable Life cycle log because the feature will only
#				collect the last 100 log entries. I modified the collection process so that only Critical
#				and Warning log entries are collected and I am separating them into a Critical log and a
#				warning log. Both are collected and placed in the LC folder. The full .xml collection still
#				happens and is the first prompt during script execution.
#				Also the information from /proc is not going to the respective folders and will no longer
#				be in a folder called proc.
#03/05/14 v3.2	This script now also allows you to collect everything, clear nothing and do it all unattended.
#				It is recommended though, if you run unattended (AND Open manage is installed)that it be run
#				on the hard disk as the	script will get the full LC log in xml format and also get human 
#				readable LC warning and	critical events. This can take 10 minutes or more on a slow USB key.
#				If you run attended you can control what logs get saved and cleared.
#03/26/14 v3.3	Optimizing and cleaning of the script.
#04/01/14 v3.4	Added /var/log/boot.msg to the /logs folder.
#				Added all Xorg logs into the /logs folder.
#04/04/14 v3.5	This script now renames the Ilvss log with the date and time it was last saved and collects it.
#				It also finds the errors in the log and saves them in "ilvss_errors.txt" in the Ilvss folder.
#				The script also collects the last Brickland package used and the ilvsslog.txt file in its
#				new date time file name.
# 04/11/14 v3.6 Fixed a problem with Ilvss log collections.
# 04/21/14 v3.7 Fixed a bug in the "ilvsslog.txt" log collection step.
#				Did a little more organization of the results.
# 04/21/14 v3.8 Optimized the driver information collection to improve performance.
#				This script is echoing the results of the "mount" command to "mount.txt" in the storage folder.
#				Removed a couple unnecessary prompts we used to get pestered by.
# 05/01/14 v3.9 Updated to support RHEL 7 RC which uses grub2.
# 05/15/14 v4.0 Added a "CardPCIlinks.txt" to the Hardware folder that contains the PCIe link states for all
#				PCI devices in the system.
#				All errors found in the message log is now saved into a date time stamped "MsgLogErrs.txt" file
#				inside the "logs" folder.
# 05/19/14 v4.1 Added the collection of, pm-suspend and pm-powersave logs.
#				Added all .cfg files in /etc.
# 05/22/14 v4.2 Added another search for just errors in the ilvss testlog.txt file as other errors do get reported
#				in the log but were not being captured. The ERRORs and errors are recorded now in separate files.
#				Whenever I actually see a miss-compare I will add code to capture those exclusively.
# 06/02/14 v4.3	Changed some verbiage for clarity.
#				The number of loops and errors from ilvss are provided in "ilvss_status.txt" in the logs ilvss folder.
# 07/18/14 v4.4 The "chkconfig --list" command that dumps run level services has been replaced with 
#				"systemctl list-unit-files" which dumps a much more complete list and their associated status's.
# 07/21/14 v4.5 Added the collection of /proc/iomem and /proc/ioports to the collection process.
# 07/22/14 v4.6	Found a small naming convention error - fixed!
#				Found a couple other gotchas in the result reporting sections - fixed.
# 08/01/14 v4.7	Found two problems collecting the LC log in human readable format - fixed!
# 08/14/14 v4.8	This script will now attempt to contact the ST domain, and if successful determine whether
#				the script is the most recent. If it is not the script will inform you that an updated script
#				exists and point you to where it is.
#				The script will then ask if you want to upgrade the script you are using. If you select yes
#				the script will overwrite itself and restart.
# 08/14/14 v4.9	Reduced the file collections within /boot/grub || /boot/grub2 to only grub* file names. Otherwise
#				there was a lot of unneeded files collected.
# 08/27/14 v5.0	This script will now and going forward upgrade itself to the most recent version without user intervention.
#				The user will be notified when the script gets upgraded.
# 09/02/14 v5.1	Fixed a small typo which caused big problems.
# 09/03/14 v5.2	Added a "Duration" function which will report how long the script took to complete.
#				The /proc/scsi/mounts file is not always present and caused an error to be logged - fixed.
# 09/03/14 v5.3 Rename the function "valip" to "validip" to match the Windows  scripts.
# 09/04/14 v5.4 Found that the SEL was being cleared during unattended execution - fixed.
#				Also the OM logs where not being placed in the correct folder - fixed.
# 09/05/14 v5.5 The Open Manage service checking was upgraded to inform the user which OM service, if any, is not running.
#				The script then attempts to start the service. If the service does not start the script informs the user
#				and continues with the rest of the log collections
# 10/08/14 v5.6 Fixed a couple problems with the log.
#				Script will no longer get the RAC Trace log in the "Unattended" mode.
# 10/09/14 v5.7 Removed the final section that deletes the results folder. This also where the log is kept and
#				the files needed for duration calculation. Deletion of the results folder is left for the user.
#				All results are still saved in the tarball and archived in the "oldtars" folder.
#				Added more storage information to the results.
# 10/15/14 v5.8 Found a couple more bugs in this thing, fixed.
# 10/23/14 v5.9 Found yet another bug that prevented the script from running to completion.
# 10/29/14 v6.0 The SUSE "systemctl" command apparently is no longer working in SLES 11 SP/3 GM. That command has been
#				replaced with "chkconfig --list" to get the list of SUSE run-level services.
#
#
#
#

clear
echo
#######################################################
# 'Setting the "rename" function to be used later.'
function rename(){
	filename=`echo $1 | sed 's/\/.*\///g'`
	folder=`echo $1 | sed -e "s/$filename//g"`
	var=`stat -c %z $vsshome/$filename|sed 's/\..*//g'|sed 's/:/-/g'`
	var1=`echo $var|sed 's/ .*//g'`
	var2=`echo $var|sed 's/[^ ]*//'|sed 's/^.//g'`	
	mv $1 $folder$var1-$var2-$filename
}

#######################################################
# 'Setting the "Pause" function to be used later.'
function pause(){
	echo Press the Enter key to continue...
	read -p "$*"
}
#######################################################
# 'Setting the "Remove0bytefiles" function used just prior to creating the .gz file.
function Remove0bytefiles(){
_home=`pwd`
find ./$_host/$_time -type d -exec ls -d {} \; > ls.txt
cd ./$_host/$_time/
find . -size 0 -exec rm {} \;
cd $_home
sed -i 1d ls.txt
while read line
do
	cd $line
	find . -size 0 -exec rm {} \;
	cd $_home
done < "ls.txt"
rm ls.txt
cd $_home
}
#######################################################
# This function moves the last .gz files into ./oldtars
function moveoldtars() {
for file in ./*.gz
do
	if [ -f "${file}" ]; then
	mv ./*.gz ./oldtars
	break
	fi
done
}

#########SCRIPT SELF-UPDATING BEGINS HERE##############
#This function confirms the DNS Name server IP is valid.
function validip(){
	local ip=$1
	local stat=1
	if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
		OIFS=$IFS
		IFS='.'
		ip=($ip)
		IFS=$OIFS
		[[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
		&& ${ip[2]} -le 255 && ${ip[2]} -le 255 ]]
		stat=$?
	fi
	return $stat
}
#########################################################
#This function will inform the user of how long the script took to execute.
function getduration() {
starts=`echo $starttime|sed 's/^.*:/:/'|sed 's/://g'`
stops=`echo $stoptime|sed 's/^.*:/:/'|sed 's/://g'`
startm=`echo $starttime|sed 's/:.*//g'`
stopm=`echo $stoptime|sed 's/:.*//g'`
if [[ $stopm -lt $startm ]]; then
	(( minutes=$startm - $stopm ))
else
	(( minutes=$stopm - $startm ))
fi
if [[ $stops -lt $starts ]]; then
	(( seconds=$starts - $stops ))
else
	(( seconds=$stops - $starts ))
fi
_time=$(date +%m%d%y-%H%M)
echo The script finished on $_time >> $log
echo The script finished on $_time
echo This script ran $minutes minutes and $seconds seconds. >> $log
echo This script ran $minutes minutes and $seconds seconds.
}
#########SCRIPT SELF-UPDATING STARTS HERE##############
echo "Looking for the ST domain, Please wait..."
scriptversion=`cat ./$scriptname|grep "# Version:"|sed q|sed 's/^.\{11\}//g'|sed '/$scriptname/d'`
DNSIP=`nslookup stfs.st.dplab.intel.com|grep -A2 stfs|sed '/stfs/d'|sed "s/^[^1]*//g"`
validip $DNSIP
if [[ $? -ne 0 ]]; then
	clear
	echo
	echo 'The script was unable to locate the ST domain.'
	echo 'Since this is the case you should look in;'
	echo '\\stfs\data\John\automation\Stress\'
	echo 'or'
	echo '\\ECSDPDFS01\Common\Dept\DIJICCommon\Test_Tools\Automation\linux'
	echo 'for a new version of' $scriptname.
	echo
	sleep 10
else
	mkdir -p /st
	mount -t cifs //$DNSIP/data /st -o username=AutoLabCFctrl,password=CFuserConsole01!
	repository=`find /st/John/automation/ -type f -printf '%T@ %p\n'|grep "ScriptVersion*"|sort -n |tail -1|cut -f2- -d" "`
	newfile=`find /st/John/automation/ -type f -printf '%T@ %p\n'|grep -w $scriptname|sed 's/[^ ]* //'`
	newversion=`cat "$newfile"|grep "# Version:"|sed q|sed 's/^.\{11\}//g'`
	if [[ "$scriptversion" != "$newversion" ]];then
		clear
		echo You are running $scriptname version $scriptversion.
		echo A new $scriptname version $newversion has been downloaded. 
		echo
		cp $newfile .
		umount /st
		echo Your script has been updated and is ready to run.
		echo
		pause
		bash -c "$PWD/$scriptname"
		exit
		
	fi 
	umount /st
fi
umount /st

#########SCRIPT SELF-UPDATING ENDS HERE##############
clear
# The next line records the current minutes and seconds on the clock for use later in determining the script run time.
starttime=`echo $(date +%M:%S)`
_time=$(date +%m%d%y-%H%M)
_host=`hostname | sed 's/.st.dplab.intel\.com*//'`
mkdir -p $_host
mkdir -p $_host/$_time
_pwd=`pwd`
logname=`echo $scriptname|sed 's/.sh//g'`
log=`echo $_pwd/$_host/$_time/$logname.log`
errorlog=`echo $_pwd/$_host/$_time/errorlog.log`
echo > $log
echo $(date +%m%d%y-%H%M) - $scriptname version $scriptversion started on $_host > $log
# 'Creating the "oldtars" folder - older tar balls will be moved here.'
if [ ! -d "oldtars" ]; then
	mkdir oldtars
fi

# Moving old .gz files to ./oldtars
moveoldtars
# Creating sub folders for files to be stored in.

mkdir -p $_host/$_time/network
mkdir -p $_host/$_time/logs
mkdir -p $_host/$_time/txt
mkdir -p $_host/$_time/etc
mkdir -p $_host/$_time/hardware
if [ -d /boot/grub ]; then mkdir -p $_host/$_time/grub; fi
if [ -d /boot/grub2 ]; then mkdir -p $_host/$_time/grub2; fi
mkdir -p $_host/$_time/storage
mkdir -p $_host/$_time/OS
mkdir -p $_host/$_time/memory
mkdir -p $_host/$_time/cpu
mkdir -p $_host/$_time/lc
clear
if [[ "$scriptversion" == "$newversion" ]]; then
	echo
	echo You are running the latest $scriptname version $scriptversion.
	echo $(date +%m%d%y-%H%M) - You are running the latest $scriptname version $scriptversion. >> $log
	echo
fi 
echo 'If Open Manage is installed It is recommended that you run this from the hard disk' 
echo 'of the system, if you plan to collect everything. The LC collection can take several' 
echo 'minutes when running on a USB key.'
echo
echo 'Also, this script can rotate the message log, clear the SEL and clear other logs'
echo 'if you select no and run attended.' 
echo
echo 'Running unattended will not change any files on the system, except for ilvss results.'
echo 'In unattended mode you will not be prompted for anything. All logs will be collected and nothing'
echo 'will be cleared.'
echo
echo 'Do you want to run this in unattended mode(y/n)?'
read -n1 input
echo
if [[ $input == "Y" || $input == "y" ]]; then
	prompt=`echo no`
	echo $(date +%m%d%y-%H%M) - Script is running in Unattended mode >> $log
	echo OK, everything gets collected and it will run to completion.
	echo
else
	prompt=`echo yes`
	echo $(date +%m%d%y-%H%M) - Script is running in Attended mode >> $log
	echo "OK, you'll be prompted when needed."
	echo
fi
if [ -d /opt/ilvss ]; then vsshome=/opt/ilvss; fi
echo $(date +%m%d%y-%H%M) - Getting Ilvss result files if present... >> $log
echo Getting Ilvss result files if present...
# Backing up and copying the most recent testlog.txt file.
if [ -e $vsshome/testlog.txt ]; then
	mkdir ./$_host/$_time/ilvss
	testlog=$vsshome/testlog.txt
	cp $testlog ./$_host/$_time/ilvss/$_host-$_time-testlog.txt 2>> $errorlog
	cat $testlog|sed -n '/ERROR/,/Package/p'|sed '/Package/d' > ./$_host/$_time/ilvss/ilvss_ERRORs.txt 2>> $errorlog
	cat $testlog|grep error > ./$_host/$_time/ilvss/ilvss_errors.txt 2>> $errorlog
	# The next line is finding the newest *pk* in any ilvss/folders.
	pkx=`find /opt/ilvss/ -type f -printf '%T@ %p\n'|grep ".pk"|sort -n |tail -1|cut -f2- -d" "`
	cp $pkx ./$_host/$_time/ilvss 2>> $errorlog
	loops=`cat /opt/ilvss/ilvsslog.txt|grep Finished|sed '$!d'|sed 's/[^0-9]*//'|sed 's/ .*//g'` 
	errs=`cat /opt/ilvss/testlog.txt|grep ERROR|wc -l`
	echo > ./$_host/$_time/ilvss/ilvss_status.txt 2>> $errorlog
	echo Your test ran $loops loops and found $errs errors  >> ./$_host/$_time/ilvss/ilvss_status.txt 2>> $errorlog
	echo >> ./$_host/$_time/ilvss/ilvss_status.txt 2>> $errorlog
	rename $vsshome/testlog.txt
	echo $(date +%m%d%y-%H%M) - Finished collecting Ilvss files... >> $log
fi

# Backing up and copying the most recent ilvsslog.txt file.
if [ -f $vsshome/ilvsslog.txt ]; then
	ilvsslog=$vsshome/ilvsslog.txt
	echo $(date +%m%d%y-%H%M) - Checking for errors in ilvsslog.txt... >> $log
	sed -n '/ERROR/,/Package/p' $ilvsslog|sed '/Package/d' > ./$_host/$_time/ilvss/ilvsslog_errors.txt 2>> $errorlog
	cp $ilvsslog ./$_host/$_time/ilvss/ 2>> $errorlog
	rename $vsshome/ilvsslog.txt
else
	mkdir ./$_host/$_time/ilvss
	echo $(date +%m%d%y-%H%M) - No Ilvss cycling log, ilvsslog.txt file was found! >> $log
	echo No Ilvss cycling log, ilvsslog.txt file was found! >> ./$_host/$_time/ilvss/nofiles.txt 2>> $errorlog
fi
if [ -f "$vsshome/ctc_error_mesg.txt" ]; then cp $vsshome/ctc_error_mesg.txt ./$_host/$_time/ilvss/; fi
echo $(date +%m%d%y-%H%M) - Copying message and mcelog logs to $PWD/$_host-$_time/logs/ >> $log	
echo "Copying message and mcelog logs and saving in $PWD/$_host-$_time/logs/."
cp /var/log/messages ./$_host/$_time/logs/$_host-$_time-messages 2>> $errorlog
echo The message log has been copied to ./$_host/$_time/logs/$_host-$_time-messages
cat /var/log/messages|grep -i --text error > ./$_host/$_time/logs/$_host-$_time-MsgLogErrs.txt
echo The message errors have been copied to ./$_host/$_time/logs/$_host-$_time-messages
if [ -f /var/log/message-* ]; then cp /var/log/message-* ./$_host/$_time/logs/; fi
if [ -f /var/log/boot.msg ]; then cp /var/log/boot.msg ./$_host/$_time/logs/; fi
cp /var/log/Xorg* ./$_host/$_time/logs/ 2>> $errorlog
last reboot > ./$_host/$_time/logs/lastrebootlog.txt 2>> $errorlog
if [ -f "/var/log/mcelog" ]; then cp /var/log/mcelog ./$_host/$_time/logs/mcelog.$_time; fi
if [ -f "/var/log/pm-powersave.log" ]; then cp /var/log/pm-powersave.log ./$_host/$_time/logs/; fi
if [ -f "/var/log/pm-suspend.log" ]; then cp /var/log/pm-suspend.log ./$_host/$_time/logs/; fi
if [[ "$prompt" == "yes" ]]; then
	echo "Do you want to rotate the OS logs (y/n)? "
	read -n1 input
	echo
		if [[ $input == "Y" || $input == "y" ]]; then
		echo $(date +%m%d%y-%H%M) - Rotation of the OS log files was initiated... >> $log
		logrotate -f /etc/logrotate.conf 2>> $errorlog 
		echo Message
		fi
fi
echo $(date +%m%d%y-%H%M) - Copying cycling logs if present... >> $log
echo "Copying cycling logs if present and placing them in $PWD/$_host/$_time/cycling."
if [ -d "/var/log/cycling" ]; then
	mkdir -p $_host/$_time/cycling
	cp -Rf /var/log/cycling/* ./$_host/$_time/cycling 2>> $errorlog 
fi
if [ -f "/var/log/*update*" ]; then cp /var/log/*update* ./$_host/$_time/; fi
echo $(date +%m%d%y-%H%M) - Copying Dell message logs, if present... >> $log
echo "Copying Dell message logs, if present, and placing them in $PWD/$_host/$_time/dell"
if [ -d "/var/log/dell" ]; then
	mkdir -p ./$_host/$_time/dell/
	cp -Rf /var/log/dell/* ./$_host/$_time/dell/ 2>> $errorlog
fi
echo $(date +%m%d%y-%H%M) - Copying everything from /boot/grub... >> $log
echo "Copying everything from /boot/grub and placing in $PWD/$_host/$_time/grub"
if [ -d /boot/grub/ ]; then cp -Rf /boot/grub/grub* ./$_host/$_time/grub/; fi
if [ -d /boot/grub2/ ]; then cp -Rf /boot/grub2/grub* ./$_host/$_time/grub2/; fi
echo $(date +%m%d%y-%H%M) - Copying fstab... >> $log
echo "Copying fstab and placing it in the $PWD/$_host/$_time/etc folder."
cp /etc/fstab ./$_host/$_time/etc/ 2>> $errorlog
echo $(date +%m%d%y-%H%M) - Copying all /etc '.conf' files.... >> $log
echo "Copying all /etc '.conf' files placing them in the $PWD/$_host/$_time/etc folder."
cp /etc/*.conf ./$_host/$_time/etc/ 2>> $errorlog
cp /etc/*.cfg ./$_host/$_time/etc/ 2>> $errorlog
echo $(date +%m%d%y-%H%M) - Copying snmpd.conf... >> $log
echo Copying snmpd.conf... and placing in the $PWD/$_host/$_time/etc folder.
if [ -f /etc/snmp/snmpd.conf ]; then cp /etc/snmp/snmpd.conf ./$_host/$_time/etc/; fi
if [ -f /etc/cups/snmp.conf ]; then cp /etc/cups/snmp.conf ./$_host/$_time/etc/cups_snmp.conf; fi

if [ -f "/etc/redhat-release" ]; then
	echo $(date +%m%d%y-%H%M) - Getting the Redhat-release file... >> $log
	echo Getting the Redhat-release file...
	cp /etc/redhat-release ./$_host/$_time/OS/redhat-release.txt 2>> $errorlog
	echo $(date +%m%d%y-%H%M) - Getting the Redhat runlevel services... >> $log
	echo Getting the Redhat runlevel services...
	systemctl list-unit-files > ./$_host/$_time/OS/runlevel_services.txt 2>> $errorlog
fi

if [ -f "/etc/SuSE-release" ]; then
	echo $(date +%m%d%y-%H%M) - Getting the SuSE-release file... >> $log
	echo Getting the SuSE-release file...
	cp /etc/SuSE-release ./$_host/$_time/OS/SuSE-release.txt 2>> $errorlog
	echo $(date +%m%d%y-%H%M) - Getting the SuSE runlevel services... >> $log
	echo Getting the SuSE runlevel services...
	systemctl list-unit-files > ./$_host/$_time/OS/runlevel_services.txt 2>> $errorlog
fi
echo $(date +%m%d%y-%H%M) - Getting OS configuration files from /etc/modprobe.d... >> $log
echo 'Getting OS configuration files from /etc/modprobe.d' and saving in $PWD/$_host/$_time/etc
cp -R /etc/modprobe.d* ./$_host/$_time/etc/ 2>> $errorlog
echo $(date +%m%d%y-%H%M) - Copying Dell specific logs... >> $log
echo "Copying Dell specific logs and placing them in $PWD/$_host/$_time/omlogs folder."
if [ -f "/opt/dell/srvadmin/etc/omarolemap" ]; then
	mkdir -p $_host/$_time/omlogs
	cp /opt/dell/srvadmin/etc/omarolemap ./$_host/$_time/omlogs 2>> $errorlog
	cp -Rf /opt/dell/srvadmin/var/log/* ./$_host/$_time/omlogs 2>> $errorlog
fi
echo
echo $(date +%m%d%y-%H%M) - Collecting OM information if installed... >> $log
echo "Collecting OM information if installed"
if [ -e "/opt/dell/srvadmin/sbin/srvadmin-services.sh" ]; then
	_racadm=`find / -name racadm`
	/opt/dell/srvadmin/sbin/srvadmin-services.sh status|grep stopped > omservices.txt
	servicesstopped=`cat omservices.txt|grep stopped|wc -l`
	if [ "$servicesstopped" -gt "0" ]; then 
		echo $(date +%m%d%y-%H%M) - One or more OM services is not running! >> $log
		echo $(date +%m%d%y-%H%M) - Attempting to start the OM services! >> $log
		echo One or more OM services is not running!
		echo Attempting to start the OM services!
		/opt/dell/srvadmin/sbin/srvadmin-services.sh restart
		echo $(date +%m%d%y-%H%M) - Finished trying to start the OM services! >> $log
		echo Finished trying to start the OM services!
		/opt/dell/srvadmin/sbin/srvadmin-services.sh status|grep stopped > omservices.txt
		servicesstopped=`cat omservices.txt|grep stopped|wc -l`
	fi
	if [ "$servicesstopped" -eq "1" ]; then
		service=`cat omservices.txt|sed 's/ .*//g'`
		echo $(date +%m%d%y-%H%M) - "This OM service ($line) did not start!" >> $log
		echo $(date +%m%d%y-%H%M) - "This could be an OM bug or an invalid OM install!" >> $log
		echo "This OM service ($line) did not start!"
		echo "This could be an OM bug or an invalid OM install!"
	fi
	if [ "$servicesstopped" -gt "1" ]; then
		sed -i 's/ .*//g' omservices.txt
		echo These OM services did not start!	
		while read line
		do
			echo $line
			echo $(date +%m%d%y-%H%M) - "This OM service ($line) did not start!" >> $log
			echo $(date +%m%d%y-%H%M) - "This could be an OM bug or an invalid OM install!" >> $log
		done < "omservices.txt"
		echo
		echo $(date +%m%d%y-%H%M) - "This could be an OM bug or an invalid OM install!" >> $log
		echo $(date +%m%d%y-%H%M) - "The OM data collection cannot be executed!" >> $log
		echo "The OM data collection cannot  be executed!"
		echo "This could be an OM bug or an invalid OM install!" 
	fi
	rm omservices.txt
	if [ "$servicesstopped" -eq "0" ]; then 
		mkdir -p $_host/$_time/omlogs/power
		mkdir -p $_host/$_time/omlogs/sensors
		mkdir -p $_host/$_time/omlogs/systemcode
		mkdir -p $_host/$_time/omlogs/systeminfo
		mkdir -p $_host/$_time/omlogs/bmc
		mkdir -p $_host/$_time/omlogs/lc
		mkdir -p $_host/$_time/omlogs/storage
		mkdir -p $_host/$_time/omlogs/systeminfo
		mkdir -p $_host/$_time/omlogs/memory
		mkdir -p $_host/$_time/omlogs/network
		mkdir -p $_host/$_time/omlogs/hardware
		mkdir -p $_host/$_time/omlogs/cpu
		mkdir -p $_host/$_time/omlogs/OS
		mkdir -p $_host/$_time/omlogs/logs
		echo
		echo $(date +%m%d%y-%H%M) - Getting BIOS setup information... >> $log
		echo Getting BIOS setup information...		
		/opt/dell/srvadmin/sbin/omreport chassis biossetup > ./$_host/$_time/omlogs/systemcode/om_bios_settings.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting BIOS information... >> $log
		echo Getting BIOS information...
		/opt/dell/srvadmin/sbin/omreport chassis bios > ./$_host/$_time/omlogs/systemcode/om_bios.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Firmware information... >> $log
		echo Getting Firmware information...
		/opt/dell/srvadmin/sbin/omreport chassis firmware > ./$_host/$_time/omlogs/bmc/om_firmware.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting FRU information... >> $log
		echo Getting FRU information...
		/opt/dell/srvadmin/sbin/omreport chassis fru > ./$_host/$_time/omlogs/systemcode/om_fru.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Chassis information... >> $log
		echo Getting Chassis information...
		/opt/dell/srvadmin/sbin/omreport chassis info > ./$_host/$_time/omlogs/systeminfo/om_chassis_info.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Memory information... >> $log
		echo Getting Memory information...
		/opt/dell/srvadmin/sbin/omreport chassis memory > ./$_host/$_time/omlogs/memory/om_memory.txt 2>> $errorlog
		cp /proc/meminfo ./$_host/$_time/memory/
		echo $(date +%m%d%y-%H%M) - Getting NIC information.. >> $log
		echo Getting NIC information...
		/opt/dell/srvadmin/sbin/omreport chassis nics > ./$_host/$_time/omlogs/network/om_nics.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Serial Port information... >> $log
		echo Getting Serial Port information...
		/opt/dell/srvadmin/sbin/omreport chassis ports > ./$_host/$_time/omlogs/hardware/om_ports.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Processor information... >> $log
		echo Getting Processor information...
		/opt/dell/srvadmin/sbin/omreport chassis processors > ./$_host/$_time/omlogs/cpu/om_processors.txt 2>> $errorlog
		/opt/dell/srvadmin/sbin/omreport chassis processors index=0 > ./$_host/$_time/omlogs/cpu/om_cpu0.txt 2>> $errorlog
		/opt/dell/srvadmin/sbin/omreport chassis processors index=1 > ./$_host/$_time/omlogs/cpu/om_cpu1.txt 2>> $errorlog
		/opt/dell/srvadmin/sbin/omreport chassis processors index=2 > ./$_host/$_time/omlogs/cpu/om_cpu2.txt 2>> $errorlog
		/opt/dell/srvadmin/sbin/omreport chassis processors index=3 > ./$_host/$_time/omlogs/cpu/om_cpu3.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Power Monitoring information... >> $log
		echo Getting Power Monitoring information...
		/opt/dell/srvadmin/sbin/omreport chassis pwrmonitoring > ./$_host/$_time/omlogs/power/om_pwrmonitoring.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Power Management information... >> $log
		echo Getting Power Management information...
		/opt/dell/srvadmin/sbin/omreport chassis pwrmanagement > ./$_host/$_time/omlogs/power/om_pwrmanagement.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Power Supply information... >> $log
		echo Getting Power Supply information...
		/opt/dell/srvadmin/sbin/omreport chassis pwrsupplies > ./$_host/$_time/omlogs/power/om_pwrsupplies.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Remote Access information... >> $log
		/opt/dell/srvadmin/sbin/omreport chassis temps > ./$_host/$_time/omlogs/sensors/om_temps.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Voltages information... >> $log
		echo Getting Voltages information...
		/opt/dell/srvadmin/sbin/omreport chassis volts > ./$_host/$_time/omlogs/power/om_volts.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Enclosure information... >> $log
		echo Getting Remote Access information...
		/opt/dell/srvadmin/sbin/omreport chassis remoteaccess > ./$_host/$_time/omlogs/om_remoteaccess.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting PCIe Slot information... >> $log
		echo Getting PCIe Slot information...
		/opt/dell/srvadmin/sbin/omreport chassis slots > ./$_host/$_time/omlogs/hardware/om_slots.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Temperature information... >> $log
		echo Getting Temperature information...
		echo Getting Enclosure information...
		/opt/dell/srvadmin/sbin/omreport storage enclosure > ./$_host/$_time/omlogs/storage/om_enclosure.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Storage Controller information... >> $log
		echo Getting Storage Controller information...
		/opt/dell/srvadmin/sbin/omreport storage controller > ./$_host/$_time/omlogs/storage/om_controller.txt 2>> $errorlog
		/opt/dell/srvadmin/sbin/omreport storage controller controller=0 > ./$_host/$_time/omlogs/storage/om_controller_storage.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Global information... >> $log
		echo Getting Global information...
		/opt/dell/srvadmin/sbin/omreport storage globalinfo > ./$_host/$_time/omlogs/storage/om_globalinfo.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Virtual Disk information... >> $log
		echo Getting Virtual Disk information...
		/opt/dell/srvadmin/sbin/omreport storage vdisk > ./$_host/$_time/omlogs/storage/om_vdisk.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting OM Command Log information... >> $log
		echo Getting OM Command Log information...
		/opt/dell/srvadmin/sbin/omreport system cmdlog > ./$_host/$_time/omlogs/om_cmdlog.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Operating System information... >> $log
		echo Getting Operating System information...
		/opt/dell/srvadmin/sbin/omreport system operatingsystem > ./$_host/$_time/omlogs/OS/om_operatingsystem.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting OM SEL Log... >> $log
		echo Getting OM SEL Log...
		/opt/dell/srvadmin/sbin/omreport system esmlog > ./$_host/$_time/omlogs/logs/om_esmlog 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting OM Alert Log... >> $log
		echo Getting OM Alert Log...
		/opt/dell/srvadmin/sbin/omreport system alertlog > ./$_host/$_time/omlogs/logs/om_alert.log 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting System Summary information... >> $log
		echo Getting System Summary information...
		/opt/dell/srvadmin/sbin/omreport system summary > ./$_host/$_time/omlogs/systeminfo/om_summary.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting System Version information... >> $log
		echo Getting System Version information...
		/opt/dell/srvadmin/sbin/omreport system version > ./$_host/$_time/omlogs/systeminfo/om_versions.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting OM Platform Events information... >> $log
		echo Getting OM Platform Events information...
		/opt/dell/srvadmin/sbin/omreport system platformevents > ./$_host/$_time/omlogs/logs/om_platformevents.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting OM POST log if available... >> $log
		echo Getting OM POST log if available...
		/opt/dell/srvadmin/sbin/omreport system postlog > ./$_host/$_time/omlogs/logs/om_postlog.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting iDRAC License information... >> $log
		echo Getting iDRAC License information...
		/opt/dell/srvadmin/sbin/omreport licenses > ./$_host/$_time/omlogs/bmc/idraclicense.txt 2>> $errorlog
		echo
		echo $(date +%m%d%y-%H%M) - Collecting more information via racadm... >> $log
		echo "Collecting more information via racadm..."
		echo $(date +%m%d%y-%H%M) - Getting sensor information... >> $log
		echo Getting sensor information...
		$_racadm getsensorinfo > ./$_host/$_time/omlogs/sensors/sensorinfo.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting system service tag... >> $log
		echo Getting system service tag...
		$_racadm getsvctag > ./$_host/$_time/omlogs/systeminfo/service_tag.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting RAC Trace log... >> $log
		if [[ "$prompt" == "yes" ]]; then
		echo "Do you want to get the RAC Trace log (y/n)? "
		read -n1 input
		echo
			if [[ $input == "Y" || $input == "y" ]]; then
				echo Getting RAC Trace log...
				$_racadm gettracelog > ./$_host/$_time/omlogs/bmc/ractracelog.txt 2>> $errorlog
				echo $(date +%m%d%y-%H%M) - Getting system information... >> $log
			fi
		fi
		echo Getting system information...
		$_racadm getsysinfo > ./$_host/$_time/omlogs/systeminfo/sysinfo.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting system code versions... >> $log
		echo Getting system code versions...
		$_racadm getversion > ./$_host/$_time/omlogs/systemcode/bios_bmc_usc_version.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting system network information... >> $log
		echo Getting system network information...
		$_racadm "ifconfig" > ./$_host/$_time/omlogs/bmc/rac_nic_info.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting Lifecycle Controller settings... >> $log
		echo Getting Lifecycle Controller settings...
		$_racadm get LifeCycleController.LCAttributes > ./$_host/$_time/omlogs/lc/lc_attributes.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting system power statistics... >> $log
		echo Getting system power statistics...
		$_racadm get system.power > ./$_host/$_time/omlogs/power/systempower.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Getting system software/firmware versions... >> $log
		echo Getting system software/firmware versions...
		$_racadm swinventory > ./$_host/$_time/omlogs/systeminfo/swinventory.txt 2>> $errorlog
		echo $(date +%m%d%y-%H%M) - Collection via racadm completed.. >> $log
		echo "Collection via racadm completed.."
		if [[ "$prompt" == "yes" ]]; then	
			echo "Would you like to clear the OM Alert log (y/n)? "
			read -n1 input
			echo
			if [[ $input == "Y" || $input == "y" ]]; then
				echo $(date +%m%d%y-%H%M) - The OM Alert log is being cleared. >> $log
				/opt/dell/srvadmin/sbin/omconfig system alertlog action=clear
			fi
		fi
		echo $(date +%m%d%y-%H%M) - Collecting the SEL and placing it in $PWD/$_host/$_time/logs >> $log
		echo Collecting the SEL and placing it in $PWD/$_host/$_time/logs
		$_racadm getsel -E > ./$_host/$_time/logs/$_host-$_time-sel.txt 2>> $errorlog
		if [[ "$prompt" == "yes" ]]; then
			echo "Would you like to clear the SEL (y/n)? "
			read -n1 input
			echo		
			if [[ $input == "Y" || $input == "y" ]]; then
				$_racadm clrsel
			fi
		fi
		if [[ "$prompt" == "yes" ]]; then
			echo "Would you like to get the LC log (this can take several minutes) (y/n)? "
			read -n1 input
			echo
			if [[ $input == "Y" || $input == "y" ]]; then
				echo $(date +%m%d%y-%H%M) - Collecting the Lifecycle Controller log... >> $log
				echo Collecting the Lifecycle Controller log...
				$_racadm lclog export -f ./$_host/$_time/lc/$_host-$_time-LC_log.xml.gz --complete 2>> $errorlog
				echo The Lifecycle Controller log was saved to $PWD/$_host/$_time/lc/$_host-$_time-LC_log.xml
			else
				echo $(date +%m%d%y-%H%M) - Continuing without collecting the LC log... >> $log
				echo Continuing without collecting the LC log...
			fi
		fi
		if [[ "$prompt" == "no" ]]; then
			echo $(date +%m%d%y-%H%M) - Collecting the Lifecycle Controller log... >> $log
			$_racadm lclog export -f ./$_host/$_time/lc/$_host-$_time-LC_log.xml.gz --complete 2>> $errorlog
			echo The Lifecycle Controller log was saved to $PWD/$_host/$_time/lc/$_host-$_time-LC_log.xml
		fi
		if [[ "$prompt" == "yes" ]]; then
			echo "Would you like to get the LC log (in a human readable format) (y/n)? "
			read -n1 input
			echo	
			if [[ $input == "Y" || $input == "y" ]]; then
				echo $(date +%m%d%y-%H%M) - Getting human readable LC log Critcal events... >> $log
				echo Getting human readable LC log Critcal events...
				$_racadm lclog view -s critical > ./$_host/$_time/lc/$_host-$_time-LC_Human_Critical.txt 2>> $errorlog
				echo $(date +%m%d%y-%H%M) - Getting human readable LC log Warning events... >> $log
				echo Getting human readable LC log Warning events...
				$_racadm lclog view -s warning > ./$_host/$_time/lc/$_host-$_time-LC_Human_Warning.txt 2>> $errorlog
			else				
				echo "Continuing without collecting the human readable LC log..."
			fi
		fi
		if [[ "$prompt" == "no" ]]; then
			echo $(date +%m%d%y-%H%M) - Getting human readable LC log Critcal events... >> $log
			echo Getting human readable LC log Critical events...
			$_racadm lclog view -s critical > ./$_host/$_time/lc/$_host-$_time-LC_Human_Critical.txt 2>> $errorlog
			echo $(date +%m%d%y-%H%M) - Getting human readable LC log Warning events... >> $log
			echo Getting human readable LC log Warning events...
			$_racadm lclog view -s warning > ./$_host/$_time/lc/$_host-$_time-LC_Human_Warning.txt 2>> $errorlog
		fi
		echo $(date +%m%d%y-%H%M) - Getting network information... >> $log
		echo Getting network information via OM and sending it to $PWD/$_host/$_time/network/om_nics_info.txt
		/opt/dell/srvadmin/sbin/omreport chassis nics|grep -i --text index|sed 's/^.\{20\}//g'|sed 's/^/\/opt\/dell\/srvadmin\/sbin\/omreport chassis nics index=/' >> nics.sh
		chmod 777 nics.sh
		./nics.sh >> ./$_host/$_time/network/om_nics_info.txt
		rm nics.sh
	fi
fi

#echo
echo $(date +%m%d%y-%H%M) - Getting system hardware information... >> $log
echo "Getting system hardware information and placing in $PWD/$_host/$_time/hardware."
lspci -vvvxxx > ./$_host/$_time/hardware/lspci_bigfatone.txt
lspci -v > ./$_host/$_time/hardware/lspci-v.txt
lspci > ./$_host/$_time/hardware/lspci.txt
df > ./$_host/$_time/storage/df.txt
#echo
echo $(date +%m%d%y-%H%M) - Saving the PCI-e link states... >> $log
echo "Saving the PCI-e link states into $PWD/$_host/$_time/hardware/PCIelinks.txt"
cat ./$_host/$_time/hardware/lspci.txt |grep -i --text unknown > ./$_host/$_time/hardware/unknown.txt
cat ./$_host/$_time/hardware/lspci_bigfatone.txt|grep -e "LnkCap" -e "LnkSta:" -e "^[[:xdigit:]][[:xdigit:]]:[[:xdigit:]][[:xdigit:]].[[:xdigit:]]"|sed 's/Port #0, //'|sed 's/Port #1, //'|sed 's/Port #2, //'|sed 's/Port #3, //'|sed 's/Port #4, //'|sed 's/Port #5, //'|sed 's/Port #6, //'|sed 's/Port #7, //'|sed 's/Port #8, //'|sed 's/Port #9, //'|sed 's/Port #10, //' > ./$_host/$_time/hardware/PCIelinks.txt
cat ./$_host/$_time/hardware/PCIelinks.txt |grep -A2 -e Ethernet -e Fibre -e "LSI Logic"|sed "/--/d" > ./$_host/$_time/hardware/CardPCIlinks.txt
cat ./$_host/$_time/hardware/PCIelinks.txt |sed "/Performance counters/d"|sed "/System peripheral/d"|sed "/--/d" > ./$_host/$_time/hardware/PCI_Links_Useful.txt
echo $(date +%m%d%y-%H%M) - Saving output from dmidecode... >> $log
echo "Executing dmidecode and saving to $PWD/$_host/$_time/hardware/dmidecode.txt"
dmidecode > ./$_host/$_time/hardware/dmidecode.txt
echo $(date +%m%d%y-%H%M) - Gathering useful files from /proc... >> $log
echo "Gathering useful files from /proc and saving in respective folders."
cp /proc/partitions ./$_host/$_time/storage/ 2>> $errorlog
cp /proc/cpuinfo ./$_host/$_time/cpu/ 2>> $errorlog
cp /proc/meminfo ./$_host/$_time/memory/ 2>> $errorlog
cp /proc/version ./$_host/$_time/OS/ 2>> $errorlog
cp /proc/iomem ./$_host/$_time/OS/ 2>> $errorlog
cp /proc/ioports ./$_host/$_time/OS/ 2>> $errorlog
cp /proc/scsi/scsi ./$_host/$_time/storage/ 2>> $errorlog
if [ -f /proc/scsi/mounts ]; then cp /proc/scsi/mounts ./$_host/$_time/storage/; fi 2>> $errorlog
mount > ./$_host/$_time/storage/mount.txt 2>> $errorlog
echo $(date +%m%d%y-%H%M) - Getting network information... >> $log
echo "Gathering network information and saving in $PWD/$_host/$_time/network."
if [ -d "/etc/sysconfig/network-scripts" ]; then cp /etc/sysconfig/network-scripts/ifcfg* ./$_host/$_time/network/; fi
if [ -d "/etc/sysconfig/network" ]; then cp /etc/sysconfig/network/ifcfg* ./$_host/$_time/network/; fi
cp /etc/hosts ./$_host/$_time/network
route > ./$_host/$_time/network/route.txt  2>> $errorlog
ifconfig -a > ./$_host/$_time/network/ifconfig.txt 2>> $errorlog
ifconfig|grep Ethernet > ./$_host/$_time/network/nic_macs.txt 2>> $errorlog
echo $(date +%m%d%y-%H%M) - Getting driver/module information... >> $log
echo "Getting driver/module information and placing it in $PWD/$_host/$_time/OS/drivers.txt"
if [ -f drivers.txt ]; then rm drivers.txt; fi
lsmod|sed 's/ .*//g'|sort | sed '/Module/d' > lsmod.txt
cat lsmod.txt|while read line
do
	modinfo $line | grep -w "version:" > version.txt
	VERSION=version.txt
	if [[ -s $VERSION ]]; then
		modinfo $line >> alldriverinfo.txt
		modinfo $line | grep -e "description:"  >> ./$_host/$_time/OS/drivers.txt
		modinfo $line | grep -w "filename:"|sed 's/\/.*\///g' >> ./$_host/$_time/OS/drivers.txt
		modinfo $line | grep -w "version:"  >> ./$_host/$_time/OS/drivers.txt
		echo >> ./$_host/$_time/OS/drivers.txt
	else
		continue
	fi
done

if [ -e "lsmod.txt" ]; then rm lsmod.txt; fi
echo $(date +%m%d%y-%H%M) - Getting a list of all installed RPMs on the system... >> $log
echo Getting a list of all installed RPMs on the system.
echo They will be in the $PWD/$_host/$_time/OS folder.
rpm -qa|sort > ./$_host/$_time/OS/installed_rpms.txt
echo $(date +%m%d%y-%H%M) - Collecting other useful files, dmesg, history, etc... >> $log
echo "Collecting other useful files, dmesg, history, etc;"
dmesg > ./$_host/$_time/logs/dmesg.txt
history > ./$_host/$_time/logs/history.txt
uname -a > ./$_host/$_time/OS/uname.txt

# "Moving remaining files to respective folders"

if [ -f "*mce*" ]; then	mv *mce* ./$_host/$_time/logs/; fi
mv *.txt ./$_host/$_time/txt/ 2>> $errorlog 2>> $errorlog
if [ -f "modprobe.conf" ]; then	mv modprobe.conf ./$_host/$_time/etc/; fi
if [ -f "*.gz" ]; then mv *.gz ./oldtars; fi

# "Creating a list of all files that will be in the tarball(host name-filelist.txt)"
ls -R ./$_host/$_time/* --ignore=oldtars | sed '/^$/d'|sed 's/^/      /'|sed 's/      .\///' > ./$_host/$_time/$_host-files-$_time.txt 2>> $errorlog
# This function is removing all empty files in all sub folders.
Remove0bytefiles
sed -i '/.sh/d' ./$_host/$_time/$_host-files-$_time.txt
sed -i '/drwxr-/d' ./$_host/$_time/$_host-files-$_time.txt
sed -i '/total/d' ./$_host/$_time/$_host-files-$_time.txt
clear
tar zcvf ./$_host-logs-$_time.tar.gz ./$_host/$_time/* --exclude=*.sh
sync
clear
echo
echo
echo
echo
echo
echo
if [ -f "$errorlog" ]; then
	echo There were errors reported in this script log, displayed below;
	cat "$errorlog"
else
	echo No errors were reported during execution.
	echo
fi
echo
stoptime=`echo $(date +%M:%S)`
getduration
echo
echo Wow that was fun...
echo
echo If theres anything you want to add, remove or change let me know. 
echo John.w.smith@intel.com
echo
echo >> $log
exit 0
