#!/bin/bash
dmesg | grep -i errors > ~/Desktop/errors.log
dmesg | grep -i error >> ~/Desktop/errors.log
dmesg | grep -i unknown > ~/Desktop/unknown.log
dmesg | grep -i conflict > ~/Desktop/conflicts.log
dmesg | grep -i conflicts >> ~/Desktop/conflicts.log
dmesg | grep -i efi > ~/Desktop/efi.log
cat /proc/cpuinfo > ~/Desktop/cpuinfo.log
cat /proc/meminfo > ~/Desktop/meminfo.log
cat /proc/net/dev > ~/Desktop/network.log
ip addr >> ~/Desktop/network.log
cat /var/log/messages > ~/Desktop/messages.log
tar czf ~/Desktop/dmesglogs.tar.gz ~/Desktop/*.log

