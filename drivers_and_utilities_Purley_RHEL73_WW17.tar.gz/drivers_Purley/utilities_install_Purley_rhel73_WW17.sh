#!/bin/bash

BKC_like() {
if [ -d /opt/BKCpkg ]; then
	echo "BKC Folder exists, installing missing RPM packages..."
	sleep 3
else 
	cp -rv /run/media/root/OS/BKCpkg /opt
fi

if [ -e "/run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso" ]; then
	mkdir -p /run/media/root/DVD
	mount -o loop /run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso /run/media/root/DVD
	cd /run/media/root/DVD/
	cp -f media.repo /etc/yum.repos.d/rhel73dvd.repo
	cd /etc/yum.repos.d/
	echo "baseurl=file:/run/media/root/DVD/" >> rhel73dvd.repo
	yum install -y --skip-broken chrony kexec-tools zlib-devel openssl-devel boost-devel libvirt-devel libgudev1-devel ncurses-devel xterm telnet numactl-libs numactl-devel-*.i686 numactl-devel *.x86_64 OpenIPMI-*.x86_64 ncurses-devel-*.x86_64 expect-*.x86_64 dos2unix systemd-devel*.x86_64 boost-*.x86_64 glibc.i686 nmap xorg-x11-apps postgresql-libs perl-ExtUtils-Embed perl-XML-Twig perl-core libibmad libibumad libibumad-devel libibcm qperf perftest rdma infinipath-psm expat elfutils-libelf-devel atlas tcl expect tcsh sysfsutils pciutils bc graphviz libtool-ltdl-devel phonon net-snmp
	umount /run/media/root/DVD
fi
}

# ilvss install
install_ilvss() {

if [ -e "/run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso" ]; then
	mkdir -p /run/media/root/DVD
	mount -o loop /run/media/root/OS/RHEL7.3x86_64/RHEL-7.3-20161019.0-Server-x86_64-dvd1.iso /run/media/root/DVD
	cd /run/media/root/DVD/
	cp -f media.repo /etc/yum.repos.d/rhel73dvd.repo
	cd /etc/yum.repos.d/
	echo "baseurl=file:/run/media/root/DVD/" >> rhel73dvd.repo
	#cd /run/media/root/DVD/Packages
	yum install -y samba telnet dos2unix libXaw libpng12 compat-libtiff3 nmap xorg-x11-apps numactl numactl-devel OpenIPMI-modalias OpenIPMI-libs OpenIPMI postgresql-libs ncurses-devel openssl098e
	umount /run/media/root/DVD
fi

cd /opt/BKCpkg/utility/ilVSS
tar -xvf ilvss-*.tar.gz
cd ilvss-*
yes | ./install
cd /opt/ilvss
nohup ./ctc &
}

# SELviewer rpm install
install_SELviewer() {
cd /opt/BKCpkg/utility/SELViewer/Linux_x64/RPM
rpm -vih *.rpm
echo "
### SELviewer INSTALL:" >> ~/Desktop/installed_utilities.log
/usr/bin/selview/selview -h >> ~/Desktop/installed_utilities.log
}

# OFU install
install_OFU() {
cd /opt/BKCpkg/utility/OFU/Linux_x64/RHEL
rpm -vih *.rpm
echo "
### OFU (flashupdt) INSTALL:" >> ~/Desktop/installed_utilities.log
/usr/bin/flashupdt/flashupdt -h >> ~/Desktop/installed_utilities.log
}

# Syscfg rpm install
install_Syscfg() {
cd /opt/BKCpkg/utility/Syscfg/Linux_x64/RHEL
rpm -vih *.rpm
echo "
### Syscfg INSTALL:" >> ~/Desktop/installed_utilities.log
/usr/bin/syscfg/./syscfg >> ~/Desktop/installed_utilities.log
}

# Sysinfo install
install_Sysinfo() {
cd /opt/BKCpkg/utility/Sysinfo/Linux_X64
chmod +x install.sh
./install.sh
echo "
### Sysinfo INSTALL:" >> ~/Desktop/installed_utilities.log
/usr/bin/sysinfo/sysinfo -h >> ~/Desktop/installed_utilities.log
}

# SNMPSA install
install_SNMPSA() {
cd /opt/BKCpkg/utility/SNMPSA/Linux_Subagent
chmod +x *.sh
service ipmi start
service snmpd start
cp -f /root/Desktop/drivers_Purley/snmpa.exp /opt/BKCpkg/utility/SNMPSA/Linux_Subagent/
chmod +x /opt/BKCpkg/utility/SNMPSA/Linux_Subagent/snmpa.exp
./snmpa.exp
echo "
### SNMPSA INSTALL:" >> ~/Desktop/installed_utilities.log
service snmpsa status >> ~/Desktop/installed_utilities.log
}

# IASC Install 
install_IASC() {
cd /opt/BKCpkg/utility/IASC/Linux/RHEL7
tar -xf ASC-*.tar.gz
cd /opt/BKCpkg/utility/IASC/Linux/RHEL7/ASC
./install
}

#BKC_like
install_ilvss
install_SELviewer
install_OFU
install_Syscfg
install_Sysinfo
install_SNMPSA
install_IASC
