#!/bin/bash

if [ -e "/root/count" ]; then
	shut_var=$(< /root/count)
	let shut_var+=1
	if [ $shut_var -ge 11 ]; then
		crontab -r
		touch /root/finished_manual_power_on_test.log
		exit
	fi
	echo $shut_var > /root/count
	/usr/sbin/shutdown now
	exit
else 
	echo 0 > /root/count
	# cat /root/count
	echo "@reboot sleep 5; /root/./shutdowner.sh" > /etc/rc.d/cronjob
	crontab -u root /etc/rc.d/cronjob
	/usr/sbin/shutdown now
	exit
fi


