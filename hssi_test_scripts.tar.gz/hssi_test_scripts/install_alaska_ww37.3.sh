#!/bin/bash
. /root/.bashrc

this_dir=$(pwd)
config=config_A0_100GCR4_100GR10_BMP_RST_EEPROM.csv 	# For copper link
# config=config_A0_100GCR4_100GR10_BMP_RST_EEPROM.csv  	# For optical link
res_0x5e=/sys/devices/pci0000\:5e/0000\:5e\:00.0/resource0
res_0xbe=/sys/devices/pci0000\:be/0000\:be\:00.0/resource0
hssi_bin_dir=/usr/Alaska_release_ww*/hssi_config_loopback/build/bin
install_logfile=alaska_install_$(date +%Y%m%d-%H%M%S).log

compile_and_install_AAL() {
# Assuming Auto_AAL_SW_AlaskaWW32.5_install_INTERNAL_ONLY.tar.gz is on /root/Desktop
cd /root/Desktop
tar -xvf Auto_AAL_SW_Alaska*_INTERNAL_ONLY.tar.gz
cd /root/Desktop/Auto_AAL_SW_Alaska*
yum install -y cmake-*.x86_64.rpm libtool-ltdl-devel-*.x86_64.rpm
yes | ./AAL_STD_Alaska_install_G*.sh

# Copy all files as indicated by BKM
echo "Copying test scripts..."
cp -vf /usr/Alaska_release_ww*/Alaska_v2.gbs /usr/bin/
cp -vf /usr/Alaska_release_ww*/Alaska_v2.gbs $hssi_bin_dir
cp -vf /usr/Alaska_release_ww*/check_host_link.sh $hssi_bin_dir
cp -vf /usr/Alaska_release_ww*/check_line_link.sh $hssi_bin_dir
cp -vf /usr/Alaska_release_ww32.5/init_scripts/config_A0_*.csv $hssi_bin_dir

# Modify init.sh to use .bashrc PATH variable (and hence /usr/bin commands)
sed -i 's|#!/usr/bin/bash|#!/bin/bash\n. /root/.bashrc|' /usr/Alaska_release_ww32.5/init.sh
sed -i 's|aliconfafu -b=Alaska_v2.gbs -B=0x$bus|aliconfafu -b=/usr/bin/Alaska_v2.gbs -B=0x$bus|' /usr/Alaska_release_ww32.5/init.sh
cp -vf /usr/Alaska_release_ww*/init.sh $hssi_bin_dir

# Copy test scripts to their respective directories
cp -vf $this_dir/config_A0_100GCR4_100GR10_BMP_RST_EEPROM.csv $hssi_bin_dir  #modified CSK according to BKM 2.2
cp -vf $this_dir/alaska_automated_* $hssi_bin_dir
cp -vf $this_dir/external_mirror_v0.1.sh $hssi_bin_dir
cp -vf $this_dir/rebooter_linux_v*.sh /root

# Copy EXTRA .csv files
cp -vf $this_dir/cpu_socket*.csv $hssi_bin_dir

# Run a driver load to verify everything is in working order
cd $hssi_bin_dir
chmod +x *.sh
./init.sh $res_0x5e $config
./init.sh $res_0xbe $config
}

compile_and_install_AAL 2>&1 | tee /root/Desktop/$install_logfile
echo "Driver installation complete and test files configured. Check /root/Desktop/$install_logfile for details"
