#!/bin/bash
. /root/.bash_profile

this_dir=$(pwd)
rev_serial_lb_dir=/usr/Alaska_release_ww*/reverse_serial_loopback/marvellous_app_pkg_api1v1/app
res_0xbe=/sys/devices/pci0000\:be/0000\:be\:00.0/resource0
fifo2=.in2.fifo

open_fifo() {
cd $rev_serial_lb_dir
if [ -e $fifo2 ]; then
	rm -f $fifo2
	mkfifo $fifo2
else
	mkfifo $fifo2
fi
}

open_s() {
#stdbuf -oL -eL 
tail -f $fifo2 | $rev_serial_lb_dir/./run.sh $res_0xbe &
hssi_pid2=$!
}

# HSSI Commands
commands() {
cat > $fifo2 &
sleep 1
echo "51" > $fifo2
sleep 1
echo "22" > $fifo2
sleep 1
echo "4" > $fifo2
sleep 1
echo "50" > $fifo2
sleep 1
echo "99" > $fifo2
}

cleanup() {
kill -9 $hssi_pid2
kill -9 $(( $hssi_pid2 - 1 ))
rm -f $fifo2
}

open_fifo
open_s
sleep 3
commands
cleanup
cd $this_dir
