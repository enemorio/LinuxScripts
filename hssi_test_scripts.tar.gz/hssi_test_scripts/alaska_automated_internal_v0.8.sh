#!/bin/bash
# Automated HSSI internal loopback test
# ----------------------------------------------
# 
# Last revision - 09/12/2017 rev 0.8

. /root/.bash_profile

# Variables

date_0=$(date +%F_%T)
hssi_bin_dir=/usr/Alaska_release_ww32.5/hssi_config_loopback/build/bin
hssi_log_dir=/root/hssi_loopback_logs
mkdir -p $hssi_log_dir
ext0=$hssi_log_dir/internal_loopback0_"$date_0"_0x5e.log
ext1=$hssi_log_dir/internal_loopback0_"$date_0"_0xbe.log
fifo0=.in0.fifo
fifo1=.in1.fifo
time=1		# in minutes

open_fifo0() {
if [ -e $fifo0 ]; then
	rm -f $fifo0
	mkfifo $fifo0
else
	mkfifo $fifo0
fi
}

open_fifo1() {
if [ -e $fifo1 ]; then
	rm -f $fifo1
	mkfifo $fifo1
else
	mkfifo $fifo1
fi
}

# Open and connect first fifo/process pair
open_s0() {
#stdbuf -oL -eL 
tail -f $fifo0 | $hssi_bin_dir/./hssi_loopback -m e100 -b 0x5e &
hssi_pid0=$!
}

open_s1() {
tail -f $fifo1 | $hssi_bin_dir/./hssi_loopback -m e100 -b 0xbe &
hssi_pid1=$!
}

# HSSI Commands
commands0a() {
cat > $fifo0 &
sleep 1
echo "stop" > $fifo0
sleep 1
echo "status clear" > $fifo0
sleep 1
echo "internal loopback start 0" > $fifo0
sleep 7
echo "stop" > $fifo0
sleep 1
echo "status clear" > $fifo0
sleep 1
echo "internal loopback start 0" > $fifo0
sleep 3
echo "log $ext0" > $fifo0
}

commands1a() {
cat > $fifo1 &
sleep 1
echo "stop" > $fifo1
sleep 1
echo "status clear" > $fifo1
sleep 1
echo "internal loopback start 0" > $fifo1
sleep 6
echo "stop" > $fifo1
sleep 1
echo "status clear" > $fifo1
sleep 1
echo "internal loopback start 0" > $fifo1
sleep 2
echo "log $ext1" > $fifo1
}

commands0b() {
echo "stop" > $fifo0
sleep 1
echo "quit" > $fifo0
sleep 1
}

commands1b() {
echo "stop" > $fifo1
sleep 1
echo "quit" > $fifo1
sleep 1
}

cleanup0() {
kill -9 $hssi_pid0
kill -9 $(( $hssi_pid0 - 1 ))
rm -f $fifo0
}

cleanup1() {
kill -9 $hssi_pid1
kill -9 $(( $hssi_pid1 - 1 ))
rm -f $fifo1
}

reporter0() {
lb0_tx0=$(cat $ext0 |grep "TX STAT" | awk '{print $4}')
lb0_rx0=$(cat $ext0 |grep "RX STAT" | awk '{print $4}')
lb0_rx_crc0=$(cat $ext0 |grep "RX CRC ERR" | awk '{print $5}')

echo "Internal loopback test started at $date_0. Test spanned $time minutes" >> $ext0

#0x5e ilb0
if [ "$lb0_rx_crc0" != "0|" ]; then
	echo "FAILED: Socket 0x5e - internal loopback 0 has CRC errors! $date_0" | tee -a $ext0
else
	echo "PASSED: Socket 0x5e - internal loopback 0 - CRC OK!" | tee -a $ext0
fi
if [ "$lb0_tx0" != "$lb0_rx0" ]; then
	echo "FAILED: Socket 0x5e - internal loopback 0 has missed packets! $date_0" | tee -a $ext0
else 
	echo "PASSED: Socket 0x5e - internal loopback 0 - TX/RX OK!" | tee -a $ext0
fi
}

reporter1() {
lb0_tx1=$(cat $ext1 |grep "TX STAT" | awk '{print $4}')
lb0_rx1=$(cat $ext1 |grep "RX STAT" | awk '{print $4}')
lb0_rx_crc1=$(cat $ext1 |grep "RX CRC ERR" | awk '{print $5}')

echo "Internal loopback test started at $date_0. Test spanned $time minutes" >> $ext1

#0xbe ilb0
if [ "$lb0_rx_crc1" != "0|" ]; then
	echo "FAILED: Socket 0xbe - internal loopback 0 has CRC errors! $date_0" | tee -a $ext1
else
	echo "PASSED: Socket 0xbe - internal loopback 0 - CRC OK!" | tee -a $ext1
fi
if [ "$lb0_tx1" != "$lb0_rx1" ]; then
	echo "FAILED: Socket 0xbe - internal loopback 0 has missed packets! $date_0" | tee -a $ext1
else 
	echo "PASSED: Socket 0xbe - internal loopback 0 - TX/RX OK!" | tee -a $ext1
fi
}

delay() {
for (( i=1; i <= $time; i=i+1 )); do
	sleep 60
	#echo "$i minutes elapsed"
done
}

open_fifo0
open_fifo1
sleep 1
open_s0
sleep 1
open_s1
sleep 1
commands0a
sleep 1
commands1a
delay
commands0b
sleep 1
commands1b
sleep 1
cleanup0
cleanup1
reporter0
reporter1
